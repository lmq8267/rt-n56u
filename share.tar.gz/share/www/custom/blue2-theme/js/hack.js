restoreLogo('xiaomi-big');
restoreBackground();
applyDarkIEImageFix();
applyHighchartsDarkTheme();
fixIPTVTablesOnDarkTheme();